import React from 'react'

const projects = () => {
  return (
    <div>projects</div>
  )
}

export default projects