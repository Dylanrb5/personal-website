import React from 'react'

const contact = () => {
  return (
    <div>contact</div>
  )
}

export default contact